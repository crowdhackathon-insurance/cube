package com.app.ea.ea;

import android.app.AlertDialog;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Address;
import android.location.Geocoder;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.NotificationCompat;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.vision.barcode.Barcode;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpVersion;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class rs2 extends FragmentActivity implements  OnMapReadyCallback,OnItemClickListener {
int kwdikos;
    GPSTracker gps;

    public String what="Oxημα με βλάβη ακινητοποιημένο ,πρόβλημα μπαταρίας";
    AutoCompleteTextView autoCompView;

    public void getMyLocationAddress() {

        Geocoder geocoder= new Geocoder(this, Locale.getDefault());

        try {
             gps=new GPSTracker(this);

            //Place your latitude and longitude
            List<Address> addresses = geocoder.getFromLocation(gps.getLatitude(),gps.getLongitude(), 1);

            if(addresses != null) {

                Address fetchedAddress = addresses.get(0);
                StringBuilder strAddress = new StringBuilder();

                for(int i=0; i<fetchedAddress.getMaxAddressLineIndex(); i++) {
                    strAddress.append(fetchedAddress.getAddressLine(i)).append("\n");
                }


            }



        }
        catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), "Could not get address..!", Toast.LENGTH_LONG).show();
        }
    }
    GoogleMap mMap;

    private static final String LOG_TAG = "ExampleApp";

    private static final String PLACES_API_BASE = "https://maps.googleapis.com/maps/api/place";
    private static final String TYPE_AUTOCOMPLETE = "/autocomplete";
    private static final String OUT_JSON = "/json";

    //------------ make your specific key ------------
    private static final String API_KEY = "AIzaSyAU9ShujnIg3IDQxtPr7Q1qOvFVdwNmWc4";

    public static ArrayList<String> autocomplete(String input) {
        ArrayList<String> resultList = null;

        HttpURLConnection conn = null;
        StringBuilder jsonResults = new StringBuilder();
        try {
            StringBuilder sb = new StringBuilder(PLACES_API_BASE + TYPE_AUTOCOMPLETE + OUT_JSON);
            sb.append("?key=" + API_KEY);
            sb.append("&components=country:gr");
            sb.append("&input=" + URLEncoder.encode(input, "utf8"));

            URL url = new URL(sb.toString());

            System.out.println("URL: "+url);
            conn = (HttpURLConnection) url.openConnection();
            InputStreamReader in = new InputStreamReader(conn.getInputStream());

            // Load the results into a StringBuilder
            int read;
            char[] buff = new char[1024];
            while ((read = in.read(buff)) != -1) {
                jsonResults.append(buff, 0, read);
            }
        } catch (MalformedURLException e) {
            Log.e(LOG_TAG, "Error processing Places API URL", e);
            return resultList;
        } catch (IOException e) {
            Log.e(LOG_TAG, "Error connecting to Places API", e);
            return resultList;
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }

        try {

            // Create a JSON object hierarchy from the results
            JSONObject jsonObj = new JSONObject(jsonResults.toString());
            JSONArray predsJsonArray = jsonObj.getJSONArray("predictions");

            // Extract the Place descriptions from the results
            resultList = new ArrayList<String>(predsJsonArray.length());
            for (int i = 0; i < predsJsonArray.length(); i++) {
                System.out.println(predsJsonArray.getJSONObject(i).getString("description"));
                System.out.println("============================================================");
                resultList.add(predsJsonArray.getJSONObject(i).getString("description"));
            }
        } catch (JSONException e) {
            Log.e(LOG_TAG, "Cannot process JSON results", e);
        }

        return resultList;
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

    }

    class GooglePlacesAutocompleteAdapter extends ArrayAdapter<String> implements Filterable {
        private ArrayList<String> resultList;

        public GooglePlacesAutocompleteAdapter(Context context, int textViewResourceId) {
            super(context, textViewResourceId);
        }

        @Override
        public int getCount() {
            return resultList.size();
        }

        @Override
        public String getItem(int index) {
            return resultList.get(index);
        }

        @Override
        public Filter getFilter() {
            Filter filter = new Filter() {
                @Override
                protected FilterResults performFiltering(CharSequence constraint) {
                    FilterResults filterResults = new FilterResults();
                    if (constraint != null) {
                        // Retrieve the autocomplete results.
                        resultList = autocomplete(constraint.toString());

                        // Assign the data to the FilterResults
                        filterResults.values = resultList;
                        filterResults.count = resultList.size();
                    }
                    return filterResults;
                }

                @Override
                protected void publishResults(CharSequence constraint, Filter.FilterResults results) {
                    if (results != null && results.count > 0) {
                        notifyDataSetChanged();
                    } else {
                        notifyDataSetInvalidated();
                    }
                }
            };
            return filter;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rs2);

        TelephonyManager tm = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
       device_id = "7327863782632";
        AutoCompleteTextView autoCompView = (AutoCompleteTextView) findViewById(R.id.autoCompleteTextView3);

        autoCompView.setAdapter(new GooglePlacesAutocompleteAdapter(this, R.layout.list_item));
        autoCompView.setOnItemClickListener(this);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync((OnMapReadyCallback) this);

        mMap = ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map))
                .getMap();
        GPSTracker gps=new GPSTracker(this);



        //parousiasi stoixeiwn

        SharedPreferences settings2;
        settings2 = getSharedPreferences("etisi", Context.MODE_PRIVATE);

        SharedPreferences settings;
        settings = getSharedPreferences("user", Context.MODE_PRIVATE);

        TextView t =(TextView) findViewById(R.id.pinakida);
        TextView tt =(TextView) findViewById(R.id.brand);
        TextView ttt =(TextView) findViewById(R.id.textView104);

         t.setText(settings.getString("marka","Ford"));
          tt.setText(settings.getString("pinakida","IBX2045"));

        ttt.setText(settings2.getString("address","TEST ADDRESS"));

        SharedPreferences sharedpreferences = getSharedPreferences("user", Context.MODE_PRIVATE);
        String c1=sharedpreferences.getString("pinakida", "");
        String c2=sharedpreferences.getString("brand", "");
        TextView oxima= (TextView)findViewById(R.id.brand);
        TextView pinakida= (TextView)findViewById(R.id.pinakida);
        //pinakida.setText(c1);
        //oxima.setText(c2);


        Geocoder coder = new Geocoder(this);
        List<Address> address = null;
        Barcode.GeoPoint p1 = null;


        try {
            address = coder.getFromLocationName(ttt.getText().toString(),5);
            Address location=address.get(0);
            location.getLatitude();
            location.getLongitude();
            mMap.addMarker(new MarkerOptions()
                    .position(new LatLng(gps.getLatitude(), gps.getLongitude()))

                    .title("Βρίσκεστε εδώ"));
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(location.getLatitude(), location.getLongitude()), 15));

        } catch (Exception e) {
           //Toast.makeText(this,"Η διεύθυνση δεν έχει ληφθεί παρακαλώ γυρίστε πίσω!",Toast.LENGTH_LONG).show();
        }


    }

    public void rev1(View w)
    {
        LinearLayout l =(LinearLayout)findViewById(R.id.sinergio);
        RadioButton b =(RadioButton)findViewById(R.id.c);
        if (b.isChecked()==true)
        {
            l.setVisibility(View.VISIBLE);
        }
        else
        {
            l.setVisibility(View.GONE);
        }
        RadioGroup l1 =(RadioGroup)findViewById(R.id.blabi);
        l1.setVisibility(View.GONE);
    }

    public String incid;
    public void end (View w)
    {
         kwdikos=0;
      what="";
        RadioButton a= (RadioButton)findViewById(R.id.a);
        RadioButton b= (RadioButton)findViewById(R.id.b);
        RadioButton c= (RadioButton)findViewById(R.id.c);
        RadioButton d= (RadioButton)findViewById(R.id.d);

        RadioButton e= (RadioButton)findViewById(R.id.e);
        RadioButton f= (RadioButton)findViewById(R.id.f);
        RadioButton g= (RadioButton)findViewById(R.id.g);
        RadioButton h= (RadioButton)findViewById(R.id.h);

        if (a.isChecked())
        {
            kwdikos=1;
            what=what+"Aτύχημα ";

        }
        if (b.isChecked())
        {
            kwdikos=2;
            what=what+"Βλάβη ";
        }

        if (c.isChecked())
        {
            incid="EF3B473D-7882-4E8C-BE67-991A65B3DF5F";
            kwdikos=10;
            what=what+",όχημα ακινητοποιημένο ";
        }
        if (d.isChecked())
        {
            incid="B0CC9FAD-AA95-4342-ADDA-E68B15C8A32C";
            kwdikos=20;
            what=what+",όχημα μή ακινητοποιημένο ";
        }

        if (e.isChecked())
        {

            incid="3FC5FB2A-2BC7-48F6-B32D-B35130E0DE92";
            kwdikos=100;
            what=what+", βλάβη μπαταρίας ";
        }
        if (f.isChecked())
        {

                incid="CEC53154-9912-49BA-A430-527200C8E3C1";
            kwdikos=200;
            what=what+", πρόβλημα στο λάστιχο ";
        }
        if (g.isChecked())
        {
            incid="CA602602-11F9-478C-B6B2-265C56B48EBE";
            kwdikos=300;
            what=what+", μηχανική βλάβη ";
        }
        if (h.isChecked())
        {
            incid="B8B5E8CE-C0B6-46C8-B7CA-EA69E51EE225";
            kwdikos=400;
            what=what+", άγνωστο πρόβλημα ";
        }
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);

        TextView t =(TextView) findViewById(R.id.brand);
        TextView tt =(TextView) findViewById(R.id.pinakida);
        TextView ttt =(TextView) findViewById(R.id.textView104);

        alertDialogBuilder.setTitle("Eπιβεβαιώστε τις πληροφορίες που θα αποσταλλούν :");

        alertDialogBuilder.setMessage("Mάρκα οχήματος : " + t.getText() + "\n Πινακίδα : " + tt.getText() + "\n Διεύθυνση : " + ttt.getText() + "\n Περίπτωση: "+what);

        // set positive button: Yes message

        alertDialogBuilder.setPositiveButton("Επιβεβαιώνω", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int id) {


                //apostoli JSON antikeimenou

                //apothikeusi sto calendar
               /* SharedPreferences settings;
                settings = getSharedPreferences("eu", Context.MODE_PRIVATE);
                String eggrafes = settings.getString("calendar", "");
                Calendar c = Calendar.getInstance();
                int seconds = c.get(Calendar.SECOND);

                if (eggrafes.length() > 5)
                    eggrafes = eggrafes + "#" + "Κλήση Οδικής Βοήθειας" + "@" + c.getTime() + "@" + seconds + "@" + "Οδική Βοήθεια" + "@no";
                else
                    eggrafes = "Κλήση Οδικής Βοήθειας" + "@" + c.getTime() + "@" + seconds + "@" + "Οδική Βοήθεια" + "@no";

                SharedPreferences.Editor editor = settings.edit();
                editor.putString("calendar", eggrafes);
                editor.commit();*/
                new get().execute();


            //minima epitixias

                //apostoli sto server


            }

        });

        // set negative button: No message

        alertDialogBuilder.setNegativeButton("Επιστροφή",new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog,int id) {

                // cancel the alert box and put a Toast to the user

                dialog.cancel();


            }

        });

        AlertDialog alertDialog = alertDialogBuilder.create();

        // show alert

        alertDialog.show();



    }
    public void rev0 (View w)
    {
        RadioGroup l =(RadioGroup)findViewById(R.id.blabi);
        l.setVisibility(View.GONE);
        LinearLayout l1 =(LinearLayout)findViewById(R.id.sinergio);
        l1.setVisibility(View.GONE);
    }
    public void onBackPressed() {
        // your code.
        Intent myIntent = new Intent(this, RSA.class);
        startActivity(myIntent);
        finish();
    }
    public void Back(View w)
    {
        Intent myIntent = new Intent(this, RSA.class);
        startActivity(myIntent);
        finish();
    }
    public void rev2 (View w)
    {
        LinearLayout l1 =(LinearLayout)findViewById(R.id.sinergio);
        l1.setVisibility(View.GONE);
        RadioGroup l =(RadioGroup)findViewById(R.id.blabi);
        RadioButton b =(RadioButton)findViewById(R.id.c);
        if (b.isChecked()==true)
        {
            l.setVisibility(View.VISIBLE);
        }
        else
        {
            l.setVisibility(View.GONE);
        }
    }

    String device_id;
    @Override
    public void onMapReady(GoogleMap googleMap) {

    }
    private class get extends AsyncTask<String, Void, String> {



        public get() {
            super();
        }

        @Override
        protected String doInBackground(String... params) {
            //connect to api
            String response_str = "";
            HttpParams pa = new BasicHttpParams();
            HttpProtocolParams.setVersion(pa, HttpVersion.HTTP_1_1);
            HttpProtocolParams.setContentCharset(pa, "utf-8");


            int timeoutConnection = 13000;
            HttpConnectionParams.setConnectionTimeout(pa, timeoutConnection);
            int timeoutSocket = 15000;
            HttpConnectionParams.setSoTimeout(pa, timeoutSocket);

            HttpClient client = new DefaultHttpClient(pa);

            //if there is a connection make a request
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            NetworkInfo ni = cm.getActiveNetworkInfo();
            if (ni != null) {

                what="";
                RadioButton a= (RadioButton)findViewById(R.id.a);
                RadioButton b= (RadioButton)findViewById(R.id.b);
                RadioButton c= (RadioButton)findViewById(R.id.c);
                RadioButton d= (RadioButton)findViewById(R.id.d);

                RadioButton e= (RadioButton)findViewById(R.id.e);
                RadioButton f= (RadioButton)findViewById(R.id.f);
                RadioButton g= (RadioButton)findViewById(R.id.g);
                RadioButton h= (RadioButton)findViewById(R.id.h);

                if (a.isChecked())
                {
                    kwdikos=1;
                    what=what+"Aτύχημα ";

                }
                if (b.isChecked())
                {
                    kwdikos=2;
                    what=what+"Βλάβη ";
                }

                if (c.isChecked())
                {
                    incid="EF3B473D-7882-4E8C-BE67-991A65B3DF5F";
                    kwdikos=10;
                    what=what+",όχημα ακινητοποιημένο ";
                }
                if (d.isChecked())
                {
                    incid="B0CC9FAD-AA95-4342-ADDA-E68B15C8A32C";
                    kwdikos=20;
                    what=what+",όχημα μή ακινητοποιημένο ";
                }

                if (e.isChecked())
                {

                    incid="3FC5FB2A-2BC7-48F6-B32D-B35130E0DE92";
                    kwdikos=100;
                    what=what+", βλάβη μπαταρίας ";
                }
                if (f.isChecked())
                {

                    incid="CEC53154-9912-49BA-A430-527200C8E3C1";
                    kwdikos=200;
                    what=what+", πρόβλημα στο λάστιχο ";
                }
                if (g.isChecked())
                {
                    incid="CA602602-11F9-478C-B6B2-265C56B48EBE";
                    kwdikos=300;
                    what=what+", μηχανική βλάβη ";
                }
                if (h.isChecked())
                {
                    incid="B8B5E8CE-C0B6-46C8-B7CA-EA69E51EE225";
                    kwdikos=400;
                    what=what+", άγνωστο πρόβλημα ";
                }


                SharedPreferences sharedpreferences = getSharedPreferences("user", Context.MODE_PRIVATE);
                String pinakida=sharedpreferences.getString("pinakida", "");
                String simvoleo=sharedpreferences.getString("simvoleo", "");
                String id=sharedpreferences.getString("IDsimv", "");
                String onoma=sharedpreferences.getString("onoma", "");
                String end=sharedpreferences.getString("end", "");

                SharedPreferences settings;
                settings = getSharedPreferences("etisi", Context.MODE_PRIVATE);

                String address=sharedpreferences.getString("address", "");

                Long tsLong = System.currentTimeMillis()/1000;
                String ts = tsLong.toString();
                HttpPost request;
                try {

               request = new HttpPost("http://146.185.175.191/cube/insert.php?contractnumb="+URLEncoder.encode(simvoleo,"UTF8")+"&plate="+URLEncoder.encode(pinakida, "UTF8")+"&lat=37.977687&longitude=23.714334&email=alex@mail.com&telephone=210528762832&address=pireos%2096%20Athina%2011854&info=ok&description="+URLEncoder.encode(what, "UTF8"));
                    request.addHeader("Content-Type","text");


                UUID uuid=UUID.randomUUID();

                /*try {
                    request.setEntity(new StringEntity("{\n" +
                            "\n" +
                                    "    \"pReq\": {\n" +
                                    "\n" +
                                    "        \"ApplicationID\": \"95e3f3ed-488f-4ff0-9a62-f500fb68c048\",\n" +
                                    "\n" +
                                    "        \"IncidentInfo\": {\n" +
                                    "\n" +
                                    "            \"ID\": "+uuid+",\n" +
                                    "\n" +
                                    "            \"PolcID\": "+id+",\n" +
                                    "\n" +
                                    "            \"Date\": \"\\/Date(1439326800000+0300)\\/\",\n" +
                                    "\n" +
                                    "            \"OccurredDate\": null,\n" +
                                    "\n" +
                                    "            \"VhclRegistrationNum\": "+pinakida+",\n" +
                                    "\n" +
                                    "            \"InsCID\": "+incid+",\n" +
                                    "\n" +
                                    "            \"ContactFirstName\": \"\",\n" +
                                    "\n" +
                                    "            \"ContactLastName\": "+onoma+",\n" +
                                    "\n" +
                                    "            \"ContactTelephone1\": null,\n" +
                                    "\n" +
                                    "            \"ContactTelephone2\": \"\",\n" +
                                    "\n" +
                                    "            \"ContactMobile1\": null,\n" +
                                    "\n" +
                                    "            \"ContactMobile2\": \"\",\n" +
                                    "\n" +
                                    "            \"JstfID\": null,\n" +
                                    "\n" +
                                    "            \"PrefID\": \"6CC9C263-311C-43CB-9E48-010BFB35C1FD\",\n" +
                                    "\n" +
                                    "            \"RegnID\": \"A836F3ED-107A-4FCC-889C-2EA967A981CA\",\n" +
                                    "\n" +
                                    "            \"Street1\": "+address+",\n" +
                                    "\n" +
                                    "            \"PlaceInfo\": \"\",\n" +
                                    "\n" +
                                    "            \"Notes\": \"\",\n" +
                                    "\n" +
                                    "            \"Latitude\": 0,\n" +
                                    "\n" +
                                    "            \"Longitude\": 0\n" +
                                    "\n" +
                                    "        },\n" +
                                    "\n" +
                                    "       \"DeviceInfo\": {\n" +
                                    "            \"DeviceBrand\": \"Sony\",\n" +
                                    "            \"DeviceModel\": \"E4\",\n" +
                                    "            \"DeviceOS\": \"Android 4.2\",\n" +
                                    "            \"DeviceAppVersion\": \"1.1\",\n" +
                                    "            \"DeviceIMEI\": \"1234567890\"\n" +
                                    "        }\n" +
                                    "\n" +
                                    "    }\n" +
                                    "\n" +
                                    "}"));
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }*/


                // Get the response
                ResponseHandler<String> responseHandler = new BasicResponseHandler();
                try {
                    HttpResponse response;
                    ConnectivityManager cm2 = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
                    NetworkInfo ni2 = cm.getActiveNetworkInfo();
                    if (ni2 != null) {

                        response = client.execute(request);
                        if (response.getStatusLine().getStatusCode() == 200) {
                            // Connection was established. Get the content.

                            HttpEntity entity = response.getEntity();
                            // If the response does not enclose an entity, there is no need
                            // to worry about connection release

                            if (entity != null) {
                                // A Simple JSON Response Read
                                String jsonText = EntityUtils.toString(entity, HTTP.UTF_8);
                                return jsonText;


                            }
                        }


                    }



                } catch (IOException ex) {
                }
                } catch (UnsupportedEncodingException e1) {
                    e1.printStackTrace();
                }


            } else {
                //no internet
            }

            return response_str;
        }


        @Override
        protected void onPostExecute(String result) {

           // Toast.makeText(getApplicationContext(),result+"", Toast.LENGTH_LONG).show();




// notificationID allows you to update the notification later on.


                   Intent myIntent = new Intent(getApplicationContext(), result.class);
                   startActivity(myIntent);
                   finish();



    }}


}


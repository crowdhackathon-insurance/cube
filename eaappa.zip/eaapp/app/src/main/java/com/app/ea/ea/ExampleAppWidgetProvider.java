package com.app.ea.ea;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.RemoteViews;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpVersion;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.SocketTimeoutException;

/**
 * Created by dimitris on 3/22/16.
 */
public class ExampleAppWidgetProvider extends AppWidgetProvider {


    String [] parts;
    RemoteViews remoteViews;

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager,
                         int[] appWidgetIds) {



        // initializing widget layout
         remoteViews = new RemoteViews(context.getPackageName(),
                R.layout.widget);


        new get().execute();

        // register for button event


        // updating view with initial data
        //remoteViews.setTextViewText(R.id.title, getTitle());
        //remoteViews.setTextViewText(R.id.desc, getDesc());

        // request for widget update
        pushWidgetUpdate(context, remoteViews);
    }

    public static PendingIntent buildButtonPendingIntent(Context context) {
        ++MyWidgetIntentReceiver.clickCount;

        // initiate widget update request
        Intent intent = new Intent();
        intent.setAction("WidgetUtils.WIDGET_UPDATE_ACTION");
        return PendingIntent.getBroadcast(context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT);

    }

    private static CharSequence getDesc() {
        return "Sync to see some of our funniest joke collections";
    }
    private class get extends AsyncTask<String, Void, String> {



        public get() {
            super();
        }

        @Override
        protected String doInBackground(String... params) {
            //connect to api
            String response_str = "";
            HttpParams pa = new BasicHttpParams();
            HttpProtocolParams.setVersion(pa, HttpVersion.HTTP_1_1);
            HttpProtocolParams.setContentCharset(pa, "utf-8");


            int timeoutConnection = 13000;
            HttpConnectionParams.setConnectionTimeout(pa, timeoutConnection);
            int timeoutSocket = 15000;
            HttpConnectionParams.setSoTimeout(pa, timeoutSocket);

            HttpClient client = new DefaultHttpClient(pa);




                HttpGet request = new HttpGet("https://traffic.cit.api.here.com/traffic/6.0/incidents.json?bbox=38.0427%2C23.6699%3B37.9377%2C23.8086&criticality=0%2C1%2C2%2C3&app_code=_7qDAo8YGLmZ63HIcJG4_A&app_id=ENBHd8cJ1wnkqj0snzyD");
                // Get the response
                ResponseHandler<String> responseHandler = new BasicResponseHandler();
                try {
                    HttpResponse response;


                        response = client.execute(request);
                        if (response.getStatusLine().getStatusCode() == 200) {
                            // Connection was established. Get the content.

                            HttpEntity entity = response.getEntity();
                            // If the response does not enclose an entity, there is no need
                            // to worry about connection release

                            if (entity != null) {
                                // A Simple JSON Response Read
                                String jsonText = EntityUtils.toString(entity, HTTP.UTF_8);
                                return jsonText;


                            }
                        }





                } catch (ConnectTimeoutException e) {
                } catch (SocketTimeoutException e) {
                } catch (IOException ex) {
                }




            return response_str;
        }


        @Override
        protected void onPostExecute(String result) {

            // Toast.makeText(getApplicationContext(),result,Toast.LENGTH_LONG).show();
            JSONObject jsonObject= null;
            try {
                jsonObject = new JSONObject(result);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            try {
                jsonObject=jsonObject.getJSONObject("TRAFFICITEMS");
            } catch (JSONException e) {
                e.printStackTrace();
            }

            try {
                JSONArray jArray = jsonObject.getJSONArray("TRAFFICITEM");

                String tosplit="";
                for(int i=0; i<jArray.length(); i++){

                    JSONObject itm=jArray.getJSONObject(i);
                    JSONArray t =itm.getJSONArray("TRAFFICITEMDESCRIPTION");
                    JSONObject itm2=t.getJSONObject(0);
                    String desc = itm2.getString("content");
                    tosplit=tosplit+desc+"#";
                    //Toast.makeText(getApplicationContext(),desc,Toast.LENGTH_LONG).show();
                }

                //antikatastasi agglikwn
                tosplit=tosplit.replaceAll("At","Σε");
                tosplit=tosplit.replaceAll("Traffic problem","Πρόβλημα κίνησης");
                tosplit=tosplit.replaceAll("Traffic Problem","Πρόβλημα κίνησης");
                tosplit=tosplit.replaceAll("Entry blocked","Μπλοκαρισμένη πρόσβαση");
                tosplit=tosplit.replaceAll("Construction work","Εκτελούντε έργα");
                tosplit=tosplit.replaceAll("Blocked","Δεν υπάρχει διεύλευση");
                tosplit=tosplit.replaceAll("lane blocked","λωρίδα κλειστή");
                tosplit=tosplit.replaceAll("Emergency lane closed","Λωρίδα ανάγκης κλειστή");
                tosplit=tosplit.replaceAll("Between","Μεταξύ");
                tosplit=tosplit.replaceAll("and","και");
                tosplit=tosplit.replaceAll("Left", "Αριστερά");
                tosplit=tosplit.replaceAll("Right", "Δεξιά");

                parts=tosplit.split("#");
remoteViews.setTextViewText(R.id.textView105,parts[0]);



            } catch (JSONException e) {
                e.printStackTrace();
            }


        }

    }

    private static CharSequence getTitle() {
        return "Funny Jokes";
    }

    public static void pushWidgetUpdate(Context context, RemoteViews remoteViews) {
        ComponentName myWidget = new ComponentName(context,
               ExampleAppWidgetProvider.class);
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        manager.updateAppWidget(myWidget, remoteViews);
    }
}

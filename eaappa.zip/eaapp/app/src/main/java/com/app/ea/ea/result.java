package com.app.ea.ea;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.AdapterView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class result extends FragmentActivity implements  OnMapReadyCallback,AdapterView.OnItemClickListener {


    public void Back(View w) {
        Intent myIntent = new Intent(this, RSA.class);
        startActivity(myIntent);
        finish();
    }

    public void onBackPressed() {
        // your code.
        Intent myIntent = new Intent(this, RSA.class);
        startActivity(myIntent);
        finish();
    }
    GoogleMap mMap;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync((OnMapReadyCallback) this);

        mMap = ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map))
                .getMap();
        GPSTracker gps=new GPSTracker(this);
        mMap.addMarker(new MarkerOptions()
                .position(new LatLng(gps.getLatitude(), gps.getLongitude()))

                .title("Η θέση του γερανού")

        );

        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(gps.getLatitude(), gps.getLongitude()), 15));
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {

    }
}

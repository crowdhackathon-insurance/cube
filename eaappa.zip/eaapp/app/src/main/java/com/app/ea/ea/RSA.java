package com.app.ea.ea;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.vision.barcode.Barcode;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;


public class RSA extends FragmentActivity implements OnMapReadyCallback,AdapterView.OnItemClickListener {
    TextView myAddress;


    private static final String True = "true";
    private static final String language = "en";

    AutoCompleteTextView autoCompView;

    public void getMyLocationAddress() {
        myAddress=(TextView)findViewById(R.id.textView9);
        Geocoder geocoder= new Geocoder(this, Locale.getDefault());

        try {
            GPSTracker gps=new GPSTracker(this);

            //Place your latitude and longitude
            List<Address> addresses = geocoder.getFromLocation(gps.getLatitude(),gps.getLongitude(), 1);

            if(addresses != null) {

                Address fetchedAddress = addresses.get(0);
                StringBuilder strAddress = new StringBuilder();

                for(int i=0; i<fetchedAddress.getMaxAddressLineIndex(); i++) {
                    strAddress.append(fetchedAddress.getAddressLine(i)).append("\n");
                }

                myAddress.setText("" +strAddress.toString());

            }

            else
                myAddress.setText("Δεν υπάρχει σύνδεση!");

        }
        catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), "Could not get address..!", Toast.LENGTH_LONG).show();
        }
    }
    GoogleMap mMap;

    private static final String LOG_TAG = "ExampleApp";

    private static final String PLACES_API_BASE = "https://maps.googleapis.com/maps/api/place";
    private static final String TYPE_AUTOCOMPLETE = "/autocomplete";
    private static final String OUT_JSON = "/json";

    //------------ make your specific key ------------
    private static final String API_KEY = "AIzaSyAU9ShujnIg3IDQxtPr7Q1qOvFVdwNmWc4";

    public static ArrayList<String> autocomplete(String input) {
        ArrayList<String> resultList = null;

        HttpURLConnection conn = null;
        StringBuilder jsonResults = new StringBuilder();
        try {
            StringBuilder sb = new StringBuilder(PLACES_API_BASE + TYPE_AUTOCOMPLETE + OUT_JSON);
            sb.append("?key=" + API_KEY);
            sb.append("&components=country:gr");
            sb.append("&input=" + URLEncoder.encode(input, "utf8"));

            URL url = new URL(sb.toString());

            System.out.println("URL: "+url);
            conn = (HttpURLConnection) url.openConnection();
            InputStreamReader in = new InputStreamReader(conn.getInputStream());

            // Load the results into a StringBuilder
            int read;
            char[] buff = new char[1024];
            while ((read = in.read(buff)) != -1) {
                jsonResults.append(buff, 0, read);
            }
        } catch (MalformedURLException e) {
            Log.e(LOG_TAG, "Error processing Places API URL", e);
            return resultList;
        } catch (IOException e) {
            Log.e(LOG_TAG, "Error connecting to Places API", e);
            return resultList;
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }

        try {

            // Create a JSON object hierarchy from the results
            JSONObject jsonObj = new JSONObject(jsonResults.toString());
            JSONArray predsJsonArray = jsonObj.getJSONArray("predictions");

            // Extract the Place descriptions from the results
            resultList = new ArrayList<String>(predsJsonArray.length());
            for (int i = 0; i < predsJsonArray.length(); i++) {
                System.out.println(predsJsonArray.getJSONObject(i).getString("description"));
                System.out.println("============================================================");
                resultList.add(predsJsonArray.getJSONObject(i).getString("description"));
            }
        } catch (JSONException e) {
            Log.e(LOG_TAG, "Cannot process JSON results", e);
        }

        return resultList;
    }
    public void onBackPressed() {

        finish();
    }

    class GooglePlacesAutocompleteAdapter extends ArrayAdapter<String> implements Filterable {
        private ArrayList<String> resultList;

        public GooglePlacesAutocompleteAdapter(Context context, int textViewResourceId) {
            super(context, textViewResourceId);
        }

        @Override
        public int getCount() {
            return resultList.size();
        }

        @Override
        public String getItem(int index) {
            return resultList.get(index);
        }

        @Override
        public Filter getFilter() {
            Filter filter = new Filter() {
                @Override
                protected FilterResults performFiltering(CharSequence constraint) {
                    FilterResults filterResults = new FilterResults();
                    if (constraint != null) {
                        // Retrieve the autocomplete results.
                        resultList = autocomplete(constraint.toString());

                        // Assign the data to the FilterResults
                        filterResults.values = resultList;
                        filterResults.count = resultList.size();
                    }
                    return filterResults;
                }

                @Override
                protected void publishResults(CharSequence constraint, Filter.FilterResults results) {
                    if (results != null && results.count > 0) {
                        notifyDataSetChanged();
                    } else {
                        notifyDataSetInvalidated();
                    }
                }
            };
            return filter;
        }
    }

    Marker pos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rs);

        AutoCompleteTextView autoCompView = (AutoCompleteTextView) findViewById(R.id.autoCompleteTextView);

        autoCompView.setAdapter(new GooglePlacesAutocompleteAdapter(this, R.layout.list_item));
        autoCompView.setOnItemClickListener(this);

        //these swsti pinakida marka kai oxima
        SharedPreferences sharedpreferences = getSharedPreferences("user", Context.MODE_PRIVATE);
        String c1=sharedpreferences.getString("pinakida", "");
        String c2=sharedpreferences.getString("brand", "");

        TextView oxima= (TextView)findViewById(R.id.brand);
        TextView pinakida= (TextView)findViewById(R.id.pinakida);
        pinakida.setText(c1);
        oxima.setText(c2);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        mMap = ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map))
                .getMap();
        GPSTracker gps=new GPSTracker(this);
        pos= mMap.addMarker(new MarkerOptions()
                .position(new LatLng(gps.getLatitude(), gps.getLongitude()))

                .title("Βρίσκεστε εδώ"));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(gps.getLatitude(), gps.getLongitude()), 15));

        List<String> spinnerArray =  new ArrayList<String>();
        spinnerArray.add("Αθήνα");
        spinnerArray.add("Θεσσαλονίκη");

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item, spinnerArray);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner sItems = (Spinner) findViewById(R.id.spinner);
        sItems.setAdapter(adapter);
        getMyLocationAddress();





    }
    public void update (View w) throws IOException {
        pos.remove();
        AutoCompleteTextView t =(AutoCompleteTextView)findViewById(R.id.autoCompleteTextView);
        Geocoder coder = new Geocoder(this);
        List<Address> address;
        Barcode.GeoPoint p1 = null;


        address = coder.getFromLocationName(t.getText().toString(),5);
        if (address==null) {
            Toast.makeText(getApplicationContext(),"Παρακαλώ εισάγεται διεύθυνση",Toast.LENGTH_SHORT).show();
        }


    }

    public void rsa(View w)
    {
        TextView t =(TextView)findViewById(R.id.textView9);
        EditText e=(EditText)findViewById(R.id.autoCompleteTextView);
        t.setText(e.getText());
    }
    public void next (View w)
    {
        //apothikeusi tvn pliroforiwn stin trexousa etisi
        SharedPreferences settings;
        settings = getSharedPreferences("etisi", Context.MODE_PRIVATE);



//set the sharedpref
        SharedPreferences.Editor editor = settings.edit();
        AutoCompleteTextView t =(AutoCompleteTextView)findViewById(R.id.autoCompleteTextView);
        TextView tt =(TextView) findViewById(R.id.textView9);
        if (t.length()>0)
            editor.putString("address", t.getText().toString());
        else
            editor.putString("address", tt.getText().toString());
        EditText ttt =(EditText)findViewById(R.id.editText);
        editor.putString("perigrafi", ttt.getText().toString());
        editor.commit();
        Intent myIntent = new Intent(this, rs2.class);
        startActivity(myIntent);
        finish();

    }
    public void Back(View w) {

    }


    @Override
    public void onMapReady(GoogleMap googleMap) {

    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

    }
}

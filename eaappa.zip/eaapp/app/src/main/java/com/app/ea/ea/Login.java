package com.app.ea.ea;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpVersion;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.SocketTimeoutException;

public class Login extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);




    }
    public void skip(View w){


    }
    EditText s;
    EditText p;
    EditText t ;
    EditText m ;

    public void sent (View w)
    {
//γραψε τις πληροφοριες
        CheckBox oroi =(CheckBox)findViewById(R.id.oroi);
        if (oroi.isChecked()) {
            SharedPreferences settings;
            settings = getSharedPreferences("user", Context.MODE_PRIVATE);

            SharedPreferences.Editor editor = settings.edit();
            s = (EditText) findViewById(R.id.simvolaio);
            p = (EditText) findViewById(R.id.pinakida);
            t = (EditText) findViewById(R.id.tilefwno);
            m = (EditText) findViewById(R.id.email);
            if (p.length() > 0) {
                if (s.length() > 0) {
                    editor.putString("simvoleo", s.getText().toString());
                    editor.putString("tilefwno", p.getText().toString());
                    editor.putString("email", m.getText().toString());
                    editor.putString("pinakida", p.getText().toString());
                    editor.commit();

               /* Toast.makeText(getApplicationContext(),"{\n" +
                        "    \"pReq\": {\n" +
                        "        \"ApplicationID\": \"95e3f3ed-488f-4ff0-9a62-f500fb68c048\",\n" +
                        "        \"PolicyOwnerID\": \"8dd39349-c47e-4960-bb5b-c0ed57cb1f26\",\n" +
                        "        \"PolicyCode\": \" "+s.getText().toString()+" \",\n" +
                        "        \"VhclRegistrationNum\": \" "+p.getText().toString()+" \",\n" +
                        "        \"InsrMobile\": \" "+t.getText().toString()+" \",\n" +
                        "        \"InsrEmail\": \" "+m.getText().toString()+" \",\n" +
                        "        \"DeviceInfo\": {\n" +
                        "            \"DeviceBrand\": \"Sony\",\n" +
                        "            \"DeviceModel\": \"E4\",\n" +
                        "            \"DeviceOS\": \"Android 4.2\",\n" +
                        "            \"DeviceAppVersion\": \"1.1\",\n" +
                        "            \"DeviceIMEI\": \"1234567890\"\n" +
                        "        }\n" +
                        "    }\n" +
                        "}",Toast.LENGTH_LONG).show();*/
                   // new get().execute();

                    Intent myIntent = new Intent(this, RSA.class);
                     startActivity(myIntent);
                    finish();
                } else
                    Toast.makeText(this, "Παρακαλώ συμπληρώστε τον αριθμό συμβολαίου σας", Toast.LENGTH_SHORT).show();
            } else
                Toast.makeText(this, "Παρακαλώ συμπληρώστε τον αριθμό κυκλοφορίας σας", Toast.LENGTH_SHORT).show();
        }
        else
            Toast.makeText(this, "Παρακαλώ αποδεχτείτε τους όρους χρήσης", Toast.LENGTH_SHORT).show();
    }



    private class get extends AsyncTask<String, Void, String> {



        public get() {
            super();
        }

        @Override
        protected String doInBackground(String... params) {
            //connect to api
            String response_str = "";
            HttpParams pa = new BasicHttpParams();
            HttpProtocolParams.setVersion(pa, HttpVersion.HTTP_1_1);
            HttpProtocolParams.setContentCharset(pa, "utf-8");


            int timeoutConnection = 13000;
            HttpConnectionParams.setConnectionTimeout(pa, timeoutConnection);
            int timeoutSocket = 15000;
            HttpConnectionParams.setSoTimeout(pa, timeoutSocket);

            HttpClient client = new DefaultHttpClient(pa);

            //if there is a connection make a request
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            NetworkInfo ni = cm.getActiveNetworkInfo();
            if (ni != null) {


                HttpPost request = new HttpPost("http://remote.upgrade.net.gr/GlxServices/thirdparty/incidents.svc/VhclAssistanceAppRegistration");
                request.addHeader("Content-Type","application/json");

                try {

                    String ss=s.getText().toString().replaceAll(" ", "");
                    String pp=p.getText().toString().replaceAll(" ", "");
                    String tt=t.getText().toString().replaceAll(" ", "");
                    String mm=m.getText().toString().replaceAll(" ", "");
                    if (tt.length()==0)
                        tt="0";
                    if (mm.length()==0)
                        mm="0";
                    request.setEntity(new StringEntity("{\n" +
                            "    \"pReq\": {\n" +
                            "        \"ApplicationID\": \"95e3f3ed-488f-4ff0-9a62-f500fb68c048\",\n" +
                            "        \"PolicyOwnerID\": \"8dd39349-c47e-4960-bb5b-c0ed57cb1f26\",\n" +
                            "        \"PolicyCode\": \""+ss+"\",\n" +
                            "        \"VhclRegistrationNum\": \""+pp+"\",\n" +
                            "        \"InsrMobile\": \""+tt+"\",\n" +
                            "        \"InsrEmail\": \""+mm+"\",\n" +
                            "        \"DeviceInfo\": {\n" +
                            "            \"DeviceBrand\": \"Sony\",\n" +
                            "            \"DeviceModel\": \"E4\",\n" +
                            "            \"DeviceOS\": \"Android 4.2\",\n" +
                            "            \"DeviceAppVersion\": \"1.1\",\n" +
                            "            \"DeviceIMEI\": \"1234567890\"\n" +
                            "        }\n" +
                            "    }\n" +
                            "}"));
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                // Get the response
                ResponseHandler<String> responseHandler = new BasicResponseHandler();
                try {
                    HttpResponse response;
                    ConnectivityManager cm2 = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
                    NetworkInfo ni2 = cm.getActiveNetworkInfo();
                    if (ni2 != null) {

                        response = client.execute(request);
                        if (response.getStatusLine().getStatusCode() == 200) {
                            // Connection was established. Get the content.

                            HttpEntity entity = response.getEntity();
                            // If the response does not enclose an entity, there is no need
                            // to worry about connection release

                            if (entity != null) {
                                // A Simple JSON Response Read
                                String jsonText = EntityUtils.toString(entity, HTTP.UTF_8);
                                return jsonText;


                            }
                        }


                    }


                } catch (ConnectTimeoutException e) {
                } catch (SocketTimeoutException e) {
                } catch (IOException ex) {
                }


            } else {
                //no internet
                Toast.makeText(Login.this,"Παρακαλώ συνθεθείτε στο ιντερνετ",Toast.LENGTH_LONG).show();
            }

            return response_str;
        }


        @Override
        protected void onPostExecute(String result) {
            //Toast.makeText(getApplicationContext(),result,Toast.LENGTH_LONG).show();


              if (result.length()>5) {

                  //dialog an apodexetai ta stoixeia
                  AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(Login.this);

                  String name = result.substring(result.indexOf("LastName") + 11, result.length());
                  name = name.substring(0, name.indexOf(",") - 1);

                  //Toast.makeText(getApplicationContext(),name.length()+"",Toast.LENGTH_LONG).show();
                  if (name.length() > 2) {
                      //Toast.makeText(getApplicationContext(),"start",Toast.LENGTH_LONG).show();
                      String sdate = result.substring(result.indexOf("StartDate") + 19, result.length());
                      sdate = sdate.substring(0, sdate.indexOf(")") - 2);

                      String simvoleo = result.substring(result.indexOf("ID") + 3, result.length());
                      simvoleo = simvoleo.substring(0, simvoleo.indexOf(")") - 2);

                      String edate = result.substring(result.indexOf("EndDate") + 19, result.length());
                      edate = edate.substring(0, edate.indexOf(")") - 2);

                      String id = result.substring(result.indexOf("ID") + 5, result.length());
                      id = id.substring(0, id.indexOf(",") - 1);

                      String add = result.substring(result.indexOf("Street1") + 10, result.length());
                      add = add.substring(0, add.indexOf(",") - 1);

                      //Toast.makeText(getApplicationContext(),"middle",Toast.LENGTH_LONG).show();

                      String etairia = result.substring(result.indexOf("InsCDescr") + 12, result.length());
                      etairia = etairia.substring(0, etairia.indexOf(",") - 1);

                      String MnfcDescr = result.substring(result.indexOf("MnfcDescr") + 11, result.length());
                      MnfcDescr = MnfcDescr.substring(0, MnfcDescr.indexOf(",") - 1);

                      String ColrDescr = result.substring(result.indexOf("ColrDescr") + 12, result.length());
                      ColrDescr = ColrDescr.substring(0, ColrDescr.indexOf(",") - 1);

                      alertDialogBuilder.setTitle("Eπιβεβαιώστε τις πληροφορίες που θα αποσταλλούν :");

                      alertDialogBuilder.setMessage("Ονοματεπώνυμο : " + name + "\n Πινακίδα : " + p.getText().toString() + "\n Διεύθυνση : " + add + "\n Όχημα:" + MnfcDescr + "\n Χρώμα:" + ColrDescr + "\n Ασφαλιστική:" + etairia + "\nΗμ. Έναρξης:" + sdate + "\nΗμ. Λήξης:" + edate);

                      SharedPreferences settings;
                      settings = getSharedPreferences("user", Context.MODE_PRIVATE);

                      SharedPreferences.Editor editor = settings.edit();


                      editor.putString("xrwma", ColrDescr);
                      editor.putString("brand", MnfcDescr);
                      editor.putString("onoma", name);
                      editor.putString("simvoleo", s.getText().toString());
                      editor.putString("asfalistiki", etairia);
                      editor.putString("start", sdate);
                      editor.putString("IDsimv", id);
                      editor.putString("end", edate);
                      editor.commit();

                      // set positive button: Yes message

                      alertDialogBuilder.setPositiveButton("Επιβεβαιώνω", new DialogInterface.OnClickListener() {

                          public void onClick(DialogInterface dialog, int id) {

                              //simiwse na kanei eisodo me ti mia
                              SharedPreferences settings;
                              settings = getSharedPreferences("user", Context.MODE_PRIVATE);

                              SharedPreferences.Editor editor = settings.edit();


                              editor.putInt("enter", 1);
                              editor.commit();
                              //eksodos


                          }

                      });

                      // set negative button: No message

                      alertDialogBuilder.setNegativeButton("Δεν επιβεβαιώνω", new DialogInterface.OnClickListener() {

                          public void onClick(DialogInterface dialog, int id) {

                              // cancel the alert box and put a Toast to the user

                              dialog.cancel();


                          }

                      });

                      AlertDialog alertDialog = alertDialogBuilder.create();

                      // show alert

                      alertDialog.show();

                  } else {
                      //Toast.makeText(getApplicationContext(), "Τα στοιχεία είναι λανθασμένα", Toast.LENGTH_LONG).show();
                      AlertDialog.Builder builder1 = new AlertDialog.Builder(Login.this);
                      builder1.setMessage("Τα στοιχεία σας δεν βρέθηκαν στη βάση δεδομένων μας επιλέξτε τι θέλετε να κάνετε :");
                      builder1.setCancelable(true);

                      builder1.setPositiveButton(
                              "Κλήση",
                              new DialogInterface.OnClickListener() {
                                  public void onClick(DialogInterface dialog, int id) {
                                      Intent callIntent = new Intent(Intent.ACTION_CALL);
                                      callIntent.setData(Uri.parse("tel:0377778888"));

                                      startActivity(callIntent);
                                      dialog.cancel();
                                  }
                              });

                      builder1.setNegativeButton(
                              "Ακύρωση",
                              new DialogInterface.OnClickListener() {
                                  public void onClick(DialogInterface dialog, int id) {
                                      dialog.cancel();
                                  }
                              });

                      AlertDialog alert11 = builder1.create();
                      alert11.show();
                  }
              }
              else {
                  Toast.makeText(getApplicationContext(), "O server δεν είναι διαθέσιμος δοκιμάστε αργότερα", Toast.LENGTH_LONG).show();
              }




    }
    }


}
